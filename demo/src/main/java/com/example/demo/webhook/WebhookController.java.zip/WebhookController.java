package com.example.demo.webhook;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/webhook")
public class WebhookController {

   private WebClient webClient;

   @Value("${hasura.graphql.endpoint}")
   private String hasuraEndpoint;

   public WebhookController(WebClient.Builder webClientBuilder) {
       this.webClient = webClientBuilder.build();
   }

   @GetMapping("/home")
   public String hello() {
       return "ok";
   }

   @PostMapping("/insertUserDetailsWithBackup")
   public ResponseEntity<Map<String, Object>> insertUserDetailsWithBackup(@RequestBody Map<String, Object> requestBody) {
       Map<String, Object> input = (Map<String, Object>) requestBody.get("input");

       try {
           // Insert into the main table directly with the values, no variables needed
           String mainMutation = """
               mutation InsertMain {
                   insert_user_details(objects: {first_name: "%s", last_name: "%s", age: %d, id: %d}) {
                       affected_rows
                   }
               }
           """;

           // Assuming `input` has the necessary fields like first_name, last_name, age, id
           String mutationQuery = String.format(mainMutation, input.get("first_name"), input.get("last_name"), input.get("age"), input.get("id"));

           // Execute the mutation directly
           Map<String, Object> mainResponse = executeMutation(mutationQuery);

           // Insert into backup tables similarly
           String backup1Mutation = """
               mutation InsertBackup1 {
                   insert_user_details_backup1(objects: {first_name: "%s", last_name: "%s", age: %d, id: %d}) {
                       affected_rows
                   }
               }
           """;
           String backup1Query = String.format(backup1Mutation, input.get("first_name"), input.get("last_name"), input.get("age"), input.get("id"));
           executeMutation(backup1Query);

           String backup2Mutation = """
               mutation InsertBackup2 {
                   insert_user_details_backup2(objects: {first_name: "%s", last_name: "%s", age: %d, id: %d}) {
                       affected_rows
                   }
               }
           """;
           String backup2Query = String.format(backup2Mutation, input.get("first_name"), input.get("last_name"), input.get("age"), input.get("id"));
           executeMutation(backup2Query);

           return ResponseEntity.ok(Map.of("success", true, "message", "Data inserted into all tables"));

       } catch (Exception e) {
           return ResponseEntity.status(500).body(Map.of("success", false, "error", e.getMessage()));
       }
   }

   private Map<String, Object> executeMutation(String mutation) {
       return this.webClient.post()
               .uri(hasuraEndpoint)
               .bodyValue(Map.of("query", mutation))
               .retrieve()
               .bodyToMono(Map.class)
               .block();
   }
}